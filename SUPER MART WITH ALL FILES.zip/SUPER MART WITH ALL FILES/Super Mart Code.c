	#include<stdio.h>      //header file
	#include <conio.h>	   //used for getch() function
	#include<time.h>       //used for sleep
	#include<stdlib.h>     //used for clear screen
	#include<unistd.h>     //used for sleep
	#include<windows.h>    //used for  system colour and for beep function
	#include<windows.h>    //used for systcolour and for beep function
	#include<string.h>     //used for string functions 
	
	
	
	//------------------------------global variable -----------------------------------------------------------------------//
			static FILE *tp;
			static FILE *tp2;	
			static FILE *a1;
			static FILE *a2;
			static FILE *a3;
			static FILE *a4;
			static FILE *a5;
			struct total{
			float totalf1;
			float totalf2;
			float totalf3;
			float totalf4;
			float totalf5;
			}s;
	//-----------------------------------------------------------structure decleration----------------------------------------------------------------------------------------//
	//-----------------------------------------------------------first floor structure decleration----------------------------------------------------------------------------//
		struct f1{
		char product_name[50];
		int product_id;
		int product_price;
		}f;
	
	//-----------------------------------------------------------second  floor structure decleration--------------------------------------------------------------------------//	
	
				struct floor2{
				int productid;
				char product_name[50];
				int productprice;
				}f2;
	
	//-----------------------------------------------------------third floor structure decleration----------------------------------------------------------------------------//	
	
			struct floor3{
			int productid;
			char product_name[50];
			int productprice;
			}f3;
	
	//-----------------------------------------------------------fourth  floor structure decleration--------------------------------------------------------------------------//	
	
			struct floor4{
			int productid;
			char product_name[50];
			int productprice;
			}f4;
	
	//-----------------------------------------------------------fifth  floor structure decleration---------------------------------------------------------------------------//	
	
			struct floor5{
			int productid;
			char product_name[50];
			int productprice;
			}f5;
	
	//----------------------------------------------------------------All functions decleration-------------------------------------------------------------------------------//
	
			int *total(char *f1[], char *f2[], char );
			int customer();
			int floors();
			int First_Floor_administrator();
			int Second_Floor_administrator();
			int Third_Floor_administrator();
			int Fourth_Floor_administrator();
			int Fifth_Floor_administrator();
			int add_product();
			int display_product();
			int delete_product();
			int administrator();
			void load();
			void key();
			int First_floor_customer();
			int Second_floor_customer();
			int Third_floor_customer();
			int Fourth_floor_customer();
			int Fifth_floor_customer();
			int delf1();
			int delf2();
			int delf3();
			int delf4();
			int delf5();
	
	//-----------------------------------------------------------------------------------------main------------------------------------------------------------------------//
	
	int main()
	{
	tp=fopen("Total2.txt","w");
	tp2=fopen("List.txt","ab+");
	fputs("********************Thank You So Much For Shopping*****************************\n",tp);
	fputs("******************************Here is Your Bill********************************\n",tp);
	fprintf(tp,"\n Products                         Price\n");
	int ch,top=223,bottom=220,border=219,i;
	system("Color ea");
	load();
	printf("\t\t\t\t\t\t"); for(i=0;i<74;i++) printf("%c",bottom); printf("\n");
	printf("\t\t\t\t\t\t%c    %c%c%c  %c%c%c %c     %c         %c%c%c%c%c%c%c %c     %c %c%c%c%c%c%c%c %c%c%c%c%c%c%c %c%c%c%c%c%c     %c\n",border,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,border);
	printf("\t\t\t\t\t\t%c    %c %c%c%c%c %c %c     %c         %c       %c     %c %c     %c %c       %c    %c     %c\n",border,border,border,bottom,bottom,border,border,border,border,border,border,border,border,border,border,border,border,border);
	printf("\t\t\t\t\t\t%c    %c      %c %c%c%c%c%c%c%c         %c%c%c%c%c%c%c %c     %c %c%c%c%c%c%c%c %c%c%c%c%c%c%c %c%c%c%c%c%c     %c\n",border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border);
	printf("\t\t\t\t\t\t%c    %c      %c %c     %c               %c %c     %c %c       %c       %c %c%c       %c\n",border,border,border,border,border,border,border,border,border,border,border,top,bottom,border);
	printf("\t\t\t\t\t\t%c    %c      %c %c     %c         %c%c%c%c%c%c%c %c%c%c%c%c%c%c %c       %c%c%c%c%c%c%c %c   %c      %c\n",border,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,top,border);
	printf("\t\t\t\t\t\t%c                                                                        %c\n",border,border);
	printf("\t\t\t\t\t\t%c                                                                        %c\n",border,border);
	printf("\t\t\t\t\t\t%c                      %c%c%c  %c%c%c %c%c%c%c%c%c%c %c%c%c%c%c%c %c%c%c%c%c%c%c                   %c\n",border,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,bottom,border);
	printf("\t\t\t\t\t\t%c                      %c %c%c%c%c %c %c     %c %c    %c    %c                      %c\n",border,border,border,bottom,bottom,border,border,border,border,border,border,border,border);
	printf("\t\t\t\t\t\t%c                      %c      %c %c%c%c%c%c%c%c %c%c%c%c%c%c    %c                      %c\n",border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border);
	printf("\t\t\t\t\t\t%c                      %c      %c %c     %c %c %c%c      %c                      %c\n",border,border,border,border,border,border,top,bottom,border);
	printf("\t\t\t\t\t\t%c                      %c      %c %c     %c %c   %c%c    %c                      %c\n",border,border,border,border,border,border,top,bottom,border);
	printf("\t\t\t\t\t\t%c                                                                        %c\n",border,border);
	printf("\t\t\t\t\t\t"); for(i=0;i<74;i++) printf("%c",top); printf("\n");
	printf("\t\t\t\t\t\t\t\tWELCOME TO MH SUPER MART\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tMH SUPER MART OF SIX FLOORS!\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tFIRST  FLOOR   = GROCERY PORTION\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tSECOND FLOOR   = PHARAMACY PORTION\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tTHIRD  FLOOR   = CROCKERY  PORTION\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tFOURTH FLOOR   = KIDS TOYS  PORTION\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tFIFTH  FLOOR   = BOOK DEPOT PORTION\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tPRESS 1 IF YOU ARE ADMINISTRATOR\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tPRESS 2 IF YOU ARE CUSTOMER\n");
	printf("\n");
	printf("\t\t\t\t\t\t\t\tENTER CHOICE:)=");
			while(1){
			scanf("%d",&ch);
			if((ch==2)||(ch==1)){
			printf("\n");
			break;	}
			else 
			printf("Kindly Follow Instruction DOnt Be Over Smart\n");	}
			switch (ch)
			{
			case 1:
			load();
			system("CLS");
			administrator();
			break;
			case 2:
			load();
			system("CLS");
			customer();
			break;  }
			}
	
	//--------------------------------------------------customer  welcome  setup---------------------------------------------//
	
	int customer(){
	int floor,border=219;
	system("color fa");
	printf("\t\t\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border);
	printf("\t\t\t\t\t\t\t%c @     @   @@@@@  @     @@@@@   @@@@@   @ @  @ @   @@@@@ %c%c\n",border,border,border);
	printf("\t\t\t\t\t\t\t%c @     @   @      @     @       @   @   @   @  @   @     %c%c\n",border,border,border);
	printf("\t\t\t\t\t\t\t%c @  @  @   @@@@@  @     @       @   @   @   @  @   @@@@@ %c%c\n",border,border,border);
	printf("\t\t\t\t\t\t\t%c @ @ @ @   @      @     @       @   @   @      @   @     %c%c\n",border,border,border);
	printf("\t\t\t\t\t\t\t%c @@   @@   @@@@@  @@@@@ @@@@@   @@@@@   @      @   @@@@@ %c%c\n",border,border,border);
	printf("\t\t\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border);
	printf("\n");
	
	//---------------------------------------------------------customer floor function working---------------------------------------------//
	
			floors();
			printf("IF YOU WANT TO EXIT PRESS 6 ELSE\n");
			printf("ENTER FLOOR NUMBER\n");
			scanf("%d",&floor);
			if(floor==1){
			First_floor_customer();} 
			
			else if(floor==2){
			Second_floor_customer();}
			
			else if(floor==3){
			Third_floor_customer();}
			
			
			else if(floor==4){
			Fourth_floor_customer();}
			
			else if (floor==5){
			Fifth_floor_customer();}
			
			else if(floor==6){
			fprintf(tp,"%.2f",s.totalf1+s.totalf2+s.totalf3+s.totalf4+s.totalf5);
			fclose(tp);
			FILE *tpts;
			char ch;
			tpts=fopen("Total2.txt","rb");
			while(!feof(tpts))
			{
				ch=fgetc(tpts);
				printf("%c",ch);
			}
			exit(1); }
			
			} 
	
	//----------------------------------------------------------------for customer-------------------------------------------------------------------//
	
	int floors(){
	char border=219;
	printf("\t\t\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border);
	printf("\t\t\t\t\t\t\t%cMH SUPER MART CONSIST OF SIX FLOORS                       %c\n",border,border);
	printf("\t\t\t\t\t\t\t%c                                                          %c\n",border,border);
	printf("\t\t\t\t\t\t\t%cFIRST   FLOOR   =  GROCERY PORTION                        %c\n",border,border);
	printf("\t\t\t\t\t\t\t%c                                                          %c\n",border,border);
	printf("\t\t\t\t\t\t\t%cSECOND  FLOOR   = PHARAMACY PORTION                       %c\n",border,border);
	printf("\t\t\t\t\t\t\t%c                                                          %c\n",border,border);
	printf("\t\t\t\t\t\t\t%cTHIRD   FLOOR   = CROCKERY  PORTION                       %c\n",border,border);
	printf("\t\t\t\t\t\t\t%c                                                          %c\n",border,border);
	printf("\t\t\t\t\t\t\t%cFOURTH  FLOOR   = KIDS TOYS  PORTION                      %c\n",border,border);
	printf("\t\t\t\t\t\t\t%c                                                          %c\n",border,border);
	printf("\t\t\t\t\t\t\t%cFIFTH   FLOOR   = BOOK DEPOT PORTION                      %c\n",border,border);
	printf("\t\t\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border,border);
	}
	
	//-----------------------------------------------------customer floor filing work-------------------------------------------------------------//
	
	//-------------------------------------------first    floor filing work through structure--------------------------------------------------------------//
	
	int First_floor_customer(){
	load();
	//	int n=20; // for item Quantity
	int choice=0;
	int quantity;
	float total2;
	//		int l;
	//		l=n+l;
	//	struct floor2 f2[l];
	FILE *fp1= fopen("one.txt","rb");
	fread(&f,sizeof(f),1,fp1);
	puts("Here First is ProductID, Product Name, and then Product Price is Shown in PKR\n");
	while(fread(&f,sizeof(f),1,fp1)==1)
	{
	if(f.product_id==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f.product_id,f.product_name);
	printf("                             %dPkr",f.product_price);
	puts(" ");	}
	fclose(fp1);
	FILE *sp1;
	sp1=fopen("one.txt","rb");
	int a=0;
	printf("How Many Product You Want to Purchase\n");
	scanf("%d",&a);
	char productname[a][40];
	float total[a];
	for(int i=0;i<a;i++)
	{
	printf("\nEnter The ID Of Product %d You Want to Purchase\n",i+1);
	scanf("%d",&choice);
	while(fread(&f,sizeof(f),1,sp1)==1){
		
	if(choice==f.product_id)
	{
		printf("3");
	break;
		}
	}
	printf("Your Choice is Here\n");
	printf("%s\t %d pkr\n",f.product_name,f.product_price);
	strcpy(productname[a],f.product_name);
	puts(productname[a]);
	printf("Enter Quantity\n");
	scanf("%d",&quantity);
	total[a]=f.product_price*quantity;
	fprintf(tp,"\n%s           %.2f\n",productname[a],total[a]);
	printf("%.2f\n",total[a]);
	total2=total2+total[a];	 }
	s.totalf1=total2;
	printf("%.2f\n",total2);
	printf("Press any key to go on floor menu section\n");
	getch();
	system("CLS");
	customer();	} 
	
	//-------------------------------------------second floor filing work through structure------------------------------------------------------------------//
	
	int Second_floor_customer(){
	load();
	//	int n=20; // for item Quantity
	int choice;
	int quantity;
	float total2;
	//		int l;
	//		l=n+l;
	//	struct floor2 f2[l];
	FILE *fp2= fopen("secondfloor.txt","rb");
	fread(&f2,sizeof(f2),1,fp2);
	puts("Here First is ProductID, Product Name, and then Product Price is Shown in PKR\n");
	while(fread(&f2,sizeof(f2),1,fp2)==1)
	{
	if(f2.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f2.productid,f2.product_name);
	printf("                             %dPkr",f2.productprice);
	puts(" ");
		}
		fclose(fp2);
		FILE *sp2;
		sp2=fopen("secondfloor.txt","rb");
	int a,j;
	printf("How Many Product You Want to Purchase\n");
	scanf("%d",&a);
	char productname[a][40];
	float total[a];
	for(int i=0;i<a;i++)
	{
	printf("\nEnter The ID Of Product %d You Want to Purchase\n",i+1);
	scanf("%d",&choice);
	while(fread(&f2,sizeof(f2),1,sp2)==1){
	if(choice==f2.productid)
	{
	break;	}
	}
	printf("Your Choice is Here\n");
	printf("%s\t %d pkr\n",f2.product_name,f2.productprice);
	strcpy(productname[a],f2.product_name);
	puts(productname[a]);
	printf("Enter Quantity\n");
	scanf("%d",&quantity);
	total[a]=f2.productprice*quantity;
	fprintf(tp,"\n%s                %.2f\n",productname[a],total[a]);
	printf("%.2f\n",total[a]);
	total2=total2+total[a];	 }
	s.totalf2=total2;
	printf("%.2f\n",total2);
	printf("Press any key to go on floor menu section\n");
	getch();
	system("CLS");
	customer();	} 
	
	//-------------------------------------------third floor customer filing work through structure-----------------------------------------------------------//	
	
	int Third_floor_customer(){
	load();
	int a;
	int choice;
	int quantity;
	float total3;
	//	struct floor3 f3[l];
	FILE *file3 = fopen("thirdfloor.txt","ab+");
	fread(&f3,sizeof(f3),1,file3);
	while(fread(&f3,sizeof(f3),1,file3)==1){
	if(f3.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f3.productid,f3.product_name);
	printf("                             %dPkr",f3.productprice);
	puts(" ");	}
	fclose(file3);
	FILE *sp3=fopen("thirdfloor.txt","rb");
	
	printf("How Many Product You Want to Purchase\n");
	scanf("%d",&a);
	char productname[a][40];
	float total[a];
	for(int i=0;i<a;i++)
	{
	printf("\nEnter The ID Of Product %d You Want to Purchase\n",i+1);
	scanf("%d",&choice);
	while(fread(&f3,sizeof(f3),1,sp3)==1)
	{
	if(choice==f3.productid){
	break; }	
	}
	printf("Your Choice is Here\n");
	printf("%s\t %d pkr\n",f3.product_name,f3.productprice);
	strcpy(productname[a],f3.product_name);
	puts(productname[a]);
	printf("Enter Quantity\n");
	scanf("%d",&quantity);
	total[a]=f3.productprice*quantity;
	fprintf(tp,"\n%s                %.2f\n",productname[a],total[a]);
	printf("%.2f\n",total[a]);
	total3=total3+total[a];	 }
	s.totalf3=total3;
	printf("%.2f\n",total3);
	printf("Press any key to go on floor menu section\n");
	getch();
	system("CLS");
	customer();	}
	
	
	//-------------------------------------------Fourth floor customer filing work through structure------------------------------------------------------------//		
	
	int Fourth_floor_customer(){ 
	load(); 
	int choice;
	int quantity;
	float total4;
	//	struct floor4 f4[l];
	FILE *file4 = fopen("fourthfloor.txt","ab+");
	
	
	while(fread(&f4,sizeof(f4),1,file4)==1){
	if(f4.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f4.productid,f4.product_name);
	printf("                             %dPkr",f4.productprice);
	puts(" ");	}
	fclose(file4);
	FILE *sp4;
	sp4=fopen("fourthfloor.txt","rb");
	int a;
	printf("How Many Product You Want to Purchase\n");
	scanf("%d",&a);
	char productname[a][40];
	float total[a];
	//	FILE *file4a= fopen("Total.txt","a");
	//	fputs("                       Total                       ",file4a);
	for(int i=0;i<a;i++)
	{
	printf("\nEnter The ID Of Product %d You Want to Purchase\n",i+1);
	scanf("%d",&choice);
	
	while(fread(&f4,sizeof(f4),1,sp4)==1)
	{
	if(choice==f4.productid){
	break; }	
	}
	printf("Your Choice is Here\n");
	printf("%s\t %d pkr\n",f4.product_name,f4.productprice);
	strcpy(productname[a],f4.product_name);
	puts(productname[a]);
	printf("Enter Quantity\n");
	scanf("%d",&quantity);
	total[a]=f4.productprice*quantity;
	//	printf("%.2f\n",total[a]);
	fprintf(tp,"\n%s                %.2f\n",productname[a],total[a]);
	total4=total4+total[a];	 }
	s.totalf4=total4;
	printf("%.2f\n",total4);
	printf("Press any key to go on floor menu section\n");
	getch();
	system("CLS");
	customer(); 	}
	
	
	//-------------------------------------------Fifth floor customer filing work   through structure------------------------------------------------------------//		
	
	int Fifth_floor_customer(){
	load();
	int choice;
	int quantity;
	float total5;
	//	struct floor5 f5[l];
	FILE *file5 = fopen("fifthfloor.txt","ab+");
	while(fread(&f5,sizeof(f5),1,file5)==1){
	if(f5.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f5.productid,f5.product_name);
	printf("                             %dPkr",f5.productprice);
	puts(" ");	}
	fclose(file5);
	FILE *sp5=fopen("fifthfloor.txt","rb");
	int a;
	printf("How Many Product You Want to Purchase\n");
	scanf("%d",&a);
	char productname[a][40];
	float total[a];
	for(int i=0;i<a;i++)
	{
	printf("\nEnter The ID Of Product %d You Want to Purchase\n",i+1);
	scanf("%d",&choice);
	
	while(fread(&f5,sizeof(f5),1,sp5)==1)
	{
	if(choice==f5.productid){
	break; }	
	}
	printf("Your Choice is Here\n");
	printf("%s\t %d pkr\n",f5.product_name,f5.productprice);
	strcpy(productname[a],f5.product_name);
	puts(productname[a]);
	printf("Enter Quantity\n");
	scanf("%d",&quantity);
	total[a]=f5.productprice*quantity;
	fprintf(tp,"\n%s                %.2f\n",productname[a],total[a]);
	printf("%.2f\n",total[a]);
	total5=total5+total[a];	}
	s.totalf5=total5;
	printf("%.2f\n",total5);
	printf("Press any key to go on floor menu section\n");
	getch();
	system("CLS");
	customer();	}
	
	
	//--------------------------------------------------------administrator floor function-----------------------------------------------------------//
	//---------------------------------------------------------first floor Administrator-------------------------------------------------------------//
	
	int First_Floor_administrator(){
	load();            
	FILE *fp2= fopen("one.txt","rb");
	fread(&f,sizeof(f),1,fp2);
	puts("Here First is ProductID, Product Name, and then Product Price is Shown in PKR\n");
	while(fread(&f,sizeof(f),1,fp2)==1)
	{
	if(f.product_id==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f.product_id,f.product_name);
	printf("                             %dPkr",f.product_price);
	puts(" ");	}
	key();
	fclose(fp2);	}
	
	
	//-------------------------------------------------Second floor Administrator-------------------------------------------------------------//
	
	int Second_Floor_administrator(){
	load();            
	FILE *fp2= fopen("secondfloor.txt","rb");
	fread(&f2,sizeof(f2),1,fp2);
	puts("Here First is ProductID, Product Name, and then Product Price is Shown in PKR\n");
	while(fread(&f2,sizeof(f2),1,fp2)==1)
	{
	if(f2.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f2.productid,f2.product_name);
	printf("                             %dPkr",f2.productprice);
	puts(" ");	}
	key();
	fclose(fp2);	}
	
	//-------------------------------------------------third floor Administrator-------------------------------------------------------------//
	
	int Third_Floor_administrator(){
	load();
	FILE *file3 = fopen("thirdfloor.txt","ab+");
	fread(&f3,sizeof(f3),1,file3);
	while(fread(&f3,sizeof(f3),1,file3)==1){
	if(f3.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f3.productid,f3.product_name);
	printf("                             %dPkr",f3.productprice);
	puts(" ");	}
	key();
	fclose(file3); };
	
	//-------------------------------------------------fourth  floor Administrator-------------------------------------------------------------//
	
	int Fourth_Floor_administrator(){
	load(); 	
	FILE *file4 = fopen("fourthfloor.txt","ab+");
	while(fread(&f4,sizeof(f4),1,file4)==1){
	if(f4.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f4.productid,f4.product_name);
	printf("                             %dPkr",f4.productprice);
	puts(" ");	}
	key();
	fclose(file4); }
	
	//-------------------------------------------------fifth floor Administrator-------------------------------------------------------------//
	
	int Fifth_Floor_administrator(){
	load();
	FILE *file5 = fopen("fifthfloor.txt","ab+");
	while(fread(&f5,sizeof(f5),1,file5)==1){
	if(f5.productid==0)
	{
	continue;
	}
	printf(" %d     %s    \n",f5.productid,f5.product_name);
	printf("                             %dPkr",f5.productprice);
	puts(" ");	}
	key();
	fclose(file5); }
	
	//--------------------------------------------delete product for administrator---------------------------------------------------------------------// 
	
	int delete_product(){
	int f1,ch4;                              //ch4 is used for product serial number for delete product function:
	FILE *d1;
	FILE *d2;
	//	FILE *d3;
	//	FILE *d4;
	//	FILE *d5;
	int productid;                        
	printf("ENTER FLOOR NUMBER\n");
	scanf("%d",&f1);
	switch(f1){
	
	case 1:
	First_Floor_administrator();
	
	printf("Enter Product Id\n");
	scanf("%d",&productid);
	d1=fopen("one.txt","rb");
	while(fread(&f,sizeof(f),1,d1)==1)
	{			
	if(f.product_id==productid){
	ch4=1;
	fclose(d1);
	break;
	}
	}
	if(ch4==1)
	{
	printf("Product Deleted Successfully\n");
	delf1(productid);
	}
	else printf("Not Found\n");
	break;
	case 2:
	Second_Floor_administrator();
	printf("Enter Product Id\n");
	scanf("%d",&productid);
	d2=fopen("secondfloor.txt","rb");
	while(fread(&f2,sizeof(f2),1,d2)==1){
	if(productid==f2.productid)
	printf("N\n");
	printf("N\n");
	ch4=1;
	fclose(d2);
	break;
	}
	if(ch4==1)
	{
	printf("Product Deleted Successfully\n");
	delf2(productid);
	}
	else printf("Not Found\n");
	break;
	case 3:
	Third_Floor_administrator();
	printf("Enter Product Id\n");
	scanf("%d",&productid);
	d1=fopen("thirdfloor.txt","rb");
	while(fread(&f3,sizeof(f3),1,d1)==1)
	{			
	if(f3.productid==productid){
	ch4=1;
	fclose(d1);
	break;
	}
	}
	if(ch4==1)
	{
	printf("Product Deleted Successfully\n");
	delf3(productid);
	}
	else printf("Not Found\n");
	break;
	case 4:
	Fourth_Floor_administrator();
	printf("Enter Product Id\n");
	scanf("%d",&productid);
	d1=fopen("fourthfloor.txt","rb");
	while(fread(&f4,sizeof(f4),1,d1)==1)
	{			
	if(f4.productid==productid){
	ch4=1;
	fclose(d1);
	break;
	}
	}
	if(ch4==1)
	{
	printf("Product Deleted Successfully\n");
	delf4(productid);
	}
	else printf("Not Found\n");
	break;
	case 5:
	Fifth_Floor_administrator();
	printf("Enter Product Id\n");
	scanf("%d",&productid);
	d1=fopen("fifthfloor.txt","rb");
	while(fread(&f5,sizeof(f5),1,d1)==1)
	{			
	if(f5.productid==productid){
	ch4=1;
	fclose(d1);
	break;
	}
	}
	if(ch4==1)
	{
	printf("Product Deleted Successfully\n");
	delf5(productid);
	}
	else printf("Not Found\n");
	break;
	}
	
	}
	//	printf("ENTER PRODUCT NAME\n");
	//	scanf("%d",&productid);
	//	printf("ENTER PRODUCT SERIAL NUMBER\n");
	//	scanf("%d",&ch4);
	//	load();
	
	
	//--------------------------------------------create product for administrator---------------------------------------------------------------------// 
	
	int add_product(){
	int ch2,f;       // f is declare for floor option:
	int ch3; //                          
	char pr_Name[100];     // pr_name is used for and is used in string beacuse of product name:
	while(ch3!=1){
	printf("ENTER FLOOR NAME\n");
	while(1){
	scanf("%d",&f);
	if((f>=1)&&(f<=5))
	break;
	else printf("Follow The inst");
	}
	printf("First Enter Product Price, Product ID, and then Product Name\n");
	FILE *ad2;
	FILE *ad1;
	FILE *ad3;
	FILE *ad4;
	switch(f)
	{
	//		case 1:
	case 2:
	ad1	=fopen("secondfloor.txt","ab");
	//	unsigned int cr=ftell(&f2);
	
	scanf(" %d  %d  %[^\n]",&f2.productprice,&f2.productid, f2.product_name);
	//fseek(ad1,cr,SEEK_SET);
	fwrite(&f2,sizeof(f2),1,ad1);
	fclose(ad1);
	break;
	case 3 :
	
	ad2=fopen("thirdfloor.txt","ab");
	
	scanf(" %d  %d  %[^\n]",&f3.productprice,&f3.productid, f3.product_name);
	//		unsigned int cr2=ftell(&f3);
	//			fseek(ad2,cr2,SEEK_SET);
	fwrite(&f3,sizeof(f3),1,ad2);
	fclose(ad2);
	break;
	case 4:
	ad3=fopen("fourthfloor.txt","ab");
	
	
	scanf(" %d  %d  %[^\n]",&f4.productprice,&f4.productid, f4.product_name);
	//		unsigned int cr3=ftell(&f4);
	//			fseek(ad3,cr3,SEEK_SET);
	fwrite(&f4,sizeof(f4),1,ad3);
	fclose(ad3);
	break;
	case 5:
	ad4=fopen("fifthfloor.txt","ab");
	
	
	scanf(" %d  %d  %[^\n]",&f5.productprice,&f5.productid, f5.product_name);
	//			unsigned int cr4=ftell(&f5);
	//		fseek(ad4,cr4,SEEK_SET);
	fwrite(&f5,sizeof(f5),1,ad4);
	fclose(ad4);
	break;
	}
	printf("If You Want to Add More Product Enter  0 else 1 Other Numbers Will Crash The Program\n");
	scanf("%d",&ch3);
	
	}
	}
	
	
	//--------------------------------------------display product for administrator---------------------------------------------------------------------// 
	
	int display_product(){
	int ch3,e;                //ch3 is used for floor in display_product function:  // in display product only floor will be asked
	floors();
	printf("ENTER WHICH FLOOR'S PRODUCT YOU WANT TO DISPLAY\n");
	scanf("%d",&ch3);
	switch(ch3)
	{		
	case 1:
	system("CLS");
	First_Floor_administrator();
	break;
	case 2:
	system("CLS");
	Second_Floor_administrator();
	break;
	case 3:
	system("CLS");
	Third_Floor_administrator();
	break;
	case 4:
	system("CLS");
	Fourth_Floor_administrator();
	break;
	case 5:
	system("CLS");
	Fifth_Floor_administrator();
	break;
	
	}
	}
	
	int administrator(){
	int ch1;
	while(1)
	{
	system("CLS");
	printf("ENTER 1 TO DISPLAY ALL PRODUCTS\n");
	printf("ENTER 2 TO DELETE PRODUCTS\n");
	printf("ENTER 3 TO ADD A NEW PRODUCT\n");
	printf("ENTER 4 TO EXIT\n");
	scanf("%d",&ch1);
	switch (ch1)
	{
	case 1:
	sleep(1);
	system("CLS");
	display_product();
	break;
	case 2:
	sleep(1);
	system("CLS");
	delete_product();
	break;
	case 3:
	sleep(1);
	system("CLS");
	add_product();
	break;
	}
	if(ch1==4)
	break;
	}
	}
	
	void load(){
	int i,j;	
	int a=176,b=175; // 176,175
	printf("\t\t\t\t\t\t\t\t         ");
	for(j=0;j<25;j++)
	printf("%c",a);
	printf("]\r");
	printf("\t\t\t\t\t\t\t\tLoading [");
	for(i=0;i<25;i++){
	Sleep(10);
	printf("%c", b);
	//		Beep(400,550);
	};
	system("CLS");
	printf("\n\n");
	}
	int delf2(int id){
	int ch=0;
	FILE *df2;
	FILE *df2a;
	df2=fopen("secondfloor.txt","rb");
	df2a=fopen("tempf2.txt","wb");
	while(fread(&f2,sizeof(f2),1,df2)==1)
	{
	if(id==f2.productid){
	ch=1;
	//printf("N");
	}
	else{
	fwrite(&f2,sizeof(f2),1,df2a);
	}
	
	}
	
	fclose(df2);
	fclose(df2a);
	remove("secondfloor.txt");
	rename("tempf2.txt","secondfloor.txt");
	}
	int delf1(int id){
	int ch=0;
	FILE *df2;
	FILE *df2a;
	df2=fopen("one.txt","rb");
	df2a=fopen("tempf1.txt","wb");
	while(fread(&f,sizeof(f),1,df2)==1)
	{
	if(id==f.product_id){
	ch=1;
	//printf("N");
	}
	else{
	fwrite(&f,sizeof(f),1,df2a);
	}
	
	}
	
	fclose(df2);
	fclose(df2a);
	remove("one.txt");
	rename("tempf1.txt","one.txt");
	}
	int delf3(int id){
	int ch=0;
	FILE *df2;
	FILE *df2a;
	df2=fopen("thirdfloor.txt","rb");
	df2a=fopen("tempf3.txt","wb");
	while(fread(&f3,sizeof(f3),1,df2)==1)
	{
	if(id==f3.productid){
	ch=1;
	//printf("N");
	}
	else{
	fwrite(&f3,sizeof(f3),1,df2a);
	}
	
	}
	
	fclose(df2);
	fclose(df2a);
	remove("thirdfloor.txt");
	rename("tempf3.txt","thirdfloor.txt");
	}
	int delf4(int id){
	int ch=0;
	FILE *df2;
	FILE *df2a;
	df2=fopen("fourthfloor.txt","rb");
	df2a=fopen("tempf4.txt","wb");
	while(fread(&f4,sizeof(f4),1,df2)==1)
	{
	if(id==f4.productid){
	ch=1;
	//printf("N");
	}
	else{
	fwrite(&f4,sizeof(f4),1,df2a);
	}
	
	}
	
	fclose(df2);
	fclose(df2a);
	remove("fourthfloor.txt");
	rename("tempf4.txt","fourthfloor.txt");
	}
	int delf5(int id){
	int ch=0;
	FILE *df2;
	FILE *df2a;
	df2=fopen("fifthfloor.txt","rb");
	df2a=fopen("tempf5.txt","wb");
	while(fread(&f5,sizeof(f5),1,df2)==1)
	{
	if(id==f5.productid){
	ch=1;
	//printf("N");
	}
	else{
	fwrite(&f5,sizeof(f5),1,df2a);
	}
	
	}
	
	fclose(df2);
	fclose(df2a);
	remove("fifthfloor.txt");
	rename("tempf5.txt","fifthfloor.txt");
	}
	
	
	void key()
	{
	printf("\n\n-------------------------------------------Press any key to continue--------------------------------------\n"); getch();
	}
	
